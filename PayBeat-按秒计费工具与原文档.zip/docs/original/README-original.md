# 工资跳动 · PAYBEAT v1

一个按工作日、工作时间和午休时段计算实时收入的本地优先网页工具。

## 当前版本

- 首次进入先完成工资规则设置，再开始计费
- 默认基准：月薪 ¥10,000，周一至周五，10:00–18:00，12:00–13:30 午休
- 每天独立结算，周末和午休不计费
- 计费中可以编辑规则，新规则从下一个工作日生效
- 数据保存在当前浏览器本机，不上传服务器
- 经典版为默认入口，Readymag 视觉版作为独立实验入口

## 本地运行

直接打开 `index.html` 即可使用。若需要电脑弹窗或手机同一 Wi‑Fi 访问：

```bash
node pay-server.js
```

然后打开：

- `http://localhost:8765/index.html`
- `http://localhost:8765/index.html?popup=1`

## 目录说明

- `index.html`：经典版第一版入口
- `pay-by-second-readymag.html`：独立创意实验版
- `pay-server.js`：本地静态服务

后续迭代请以这个文件夹为基准，原始设计文件仍保存在上一级 `outputs` 文件夹。

## Figma 交接

当前经典版的画板尺寸、间距、颜色、字体、组件和状态数据见 [docs/ui-specs-v1.md](docs/ui-specs-v1.md)。
